"""설정 로더와 assert 검증. 과제 1 Part A."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest
import yaml

from core import asserts, config
from core.config import Config, ConfigError

BASE = Path(__file__).resolve().parent.parent / "configs" / "base.yaml"


def _raw() -> dict:
    with open(BASE, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _with(**overrides) -> Config:
    """base.yaml 을 얕게 변형해 assert 없이 Config 로 만든다. overrides 는 'a.b.c': v 형식."""
    d = copy.deepcopy(_raw())
    for dotted, value in overrides.items():
        keys = dotted.split(".")
        node = d
        for k in keys[:-1]:
            node = node[k]
        node[keys[-1]] = value
    return config.from_dict(d)


# ── 정상 로드 ────────────────────────────────────────────────────────────────

def test_valid_config_loads():
    cfg = config.load(BASE)
    assert cfg.thresholds.interceptor == 16038
    assert cfg.k == pytest.approx(0.3)          # eff 1.0 × success_prob 0.3


def test_window_values():
    """A-4 자가검증: A 5400  B 9000  E 12960  <  임계 16038  <  C×0.6 16200.

    100턴·주기 20 으로 가면서 전부 정확히 2배가 됐다 (창은 total_turns 에 선형).
    """
    cfg = config.load(BASE)
    a, b, c, e = asserts.window(cfg)
    assert a == pytest.approx(5400)
    assert b == pytest.approx(9000)
    assert e == pytest.approx(12960)
    assert c * 0.6 == pytest.approx(16200)
    assert a < b < e < cfg.thresholds.interceptor < c * 0.6


# ── 일부러 깨뜨리기 (A-4 표) ──────────────────────────────────────────────────

def test_break_interceptor_4000():
    fails = asserts.check_all(_with(**{"thresholds.interceptor": 4000}))
    joined = " ".join(fails)
    assert "★B" in joined
    assert "★E" in joined


def test_break_interceptor_above_window():
    fails = asserts.check_all(_with(**{"thresholds.interceptor": 16400}))
    assert any("★C" in f for f in fails)


def test_break_bunker_shallow():
    """벙커가 한 주기 진척(=to_progress(국가_한주기)=1800) 미만이면 벙커↓ 가 걸린다.

    ⚠ 과제 A-4 표는 `bunker_scale: 1000` 을 예로 드는데, 스펙 공식상 하한은
       (50턴 시절) 900 이라 1000 은 통과했다. 100턴에서는 하한이 1800 이다.
       하한 미만인 1600 으로 벙커↓ 를 시연한다 → A-4 예시값이 스펙과 어긋나는 지점.
    """
    fails = asserts.check_all(_with(**{"thresholds.bunker_scale": 1600}))
    assert any("벙커↓" in f for f in fails)


def test_bunker_just_above_floor():
    """하한(1800) 바로 위는 통과한다 — 경계가 어디인지를 코드로 고정."""
    fails = asserts.check_all(_with(**{"thresholds.bunker_scale": 2000}))
    assert not any("벙커↓" in f for f in fails)


def test_break_success_prob_half():
    """임계는 그대로 두고 success_prob 만 0.5 → 임계가 진척 단위임이 드러나 검사가 걸린다.

    ⚠ 과제 A-4 표는 ★C 라 적었지만, 스펙 공식으로 계산하면 창이 위로 이동(E=10800)해
       interceptor(8019)가 하한 아래로 내려가 실제로는 ★E 가 걸린다. 요점(임계가 진척
       단위라 재계산을 잊으면 검사가 잡는다)은 동일. → A-4 라벨이 스펙과 어긋나는 지점.
    """
    fails = asserts.check_all(_with(**{"world.success_prob": 0.5}))
    assert fails                              # 어떤 검사든 반드시 걸려야 한다
    assert any("★E" in f for f in fails)      # 스펙 공식상 실제로 걸리는 것은 ★E


def test_break_knob_low():
    """comm_intl_ai 최저값이 learner(5) 이하면 노브가 무의미."""
    fails = asserts.check_all(_with(**{"knob.comm_intl_ai": [4, 12]}))
    assert any("노브" in f for f in fails)


def test_load_raises_on_broken():
    d = copy.deepcopy(_raw())
    d["thresholds"]["interceptor"] = 4000
    import tempfile
    with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False, encoding="utf-8") as tf:
        yaml.safe_dump(d, tf)
        path = tf.name
    with pytest.raises(ConfigError):
        config.load(path)


# ── 백엔드 ─────────────────────────────────────────────────────────────────────

def test_gemini_backend_drops_openrouter_only_fields():
    """**OpenRouter 전용 필드는 저쪽에 없는 이름이다** — 실으면 400 이다.

    `provider`(프로바이더 라우팅)와 `reasoning`(OpenRouter 통합 사고 파라미터)은
    Google 의 OpenAI 호환 엔드포인트에 없다. config 에는 둘 다 들어 있으므로, 백엔드를
    바꿀 때 **몸통에서 빼는 것을 잊으면 전 호출이 400** 이다.
    """
    from core.llm import BACKENDS, OpenRouterClient

    sent = {}

    def fake_urlopen(req, timeout=None):
        sent["url"], sent["body"] = req.full_url, json.loads(req.data)
        raise RuntimeError("여기까지 보면 된다")

    # **클라이언트는 별 스레드에서 urlopen 을 부른다** (`_call_with_deadline`). 그래서
    # 예외가 밖으로 안 나오고 `box["exc"]` 로 옮겨져 다시 던져진다 — 어느 쪽이든
    # `sent` 는 채워지므로 그것만 본다.
    import urllib.request
    orig = urllib.request.urlopen
    urllib.request.urlopen = fake_urlopen
    try:
        for backend, expect in (("openrouter", True), ("gemini", False)):
            c = OpenRouterClient("m/x", api_key="k", backend=backend,
                                 reasoning={"enabled": False},
                                 provider={"order": ["a"]}, retries=1)
            try:
                c.chat([{"role": "user", "content": "x"}])
            except Exception:
                pass
            assert sent["url"] == BACKENDS[backend], backend
            assert ("provider" in sent["body"]) is expect, backend
            assert ("reasoning" in sent["body"]) is expect, backend
            # 몸통의 공통부는 그대로다
            assert sent["body"]["model"] == "m/x"
    finally:
        urllib.request.urlopen = orig


def test_each_backend_has_its_own_key_name():
    """열쇠가 백엔드마다 다르다. 이름을 잘못 집으면 남의 열쇠로 부른다."""
    from core.llm import BACKENDS, KEY_ENV, key_for
    assert set(KEY_ENV) == set(BACKENDS)
    assert KEY_ENV["gemini"] == "GEMINI_API_KEY"
    with pytest.raises(RuntimeError, match="모르는 백엔드"):
        key_for("nope")
